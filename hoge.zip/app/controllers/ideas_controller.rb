class IdeasController < ApplicationController
  def index
  end
end